package com.example.mobiletechapp;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        TextView textView = findViewById(R.id.textViewOutput);

        // Safely handle incoming intent data
        Bundle extras = getIntent().getExtras();
        if (extras != null && extras.containsKey("message")) {
            String msg = extras.getString("message");
            textView.setText(msg);
        } else {
            textView.setText("Welcome to Mobile Tech App");
        }
    }

    public void displayMessage(View view) {
        TextView textView = findViewById(R.id.textViewOutput);
        EditText editText = findViewById(R.id.editTextInput);

        // Update TextView with user input
        textView.setText(editText.getText().toString());

        // Show confirmation Toast
        Toast.makeText(this, "OK button clicked.", Toast.LENGTH_LONG).show();
    }
}