package com.example.mobiletechapp;

import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.Looper;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;

import java.util.List;
import java.util.Locale;

public class LocationServicesActivity extends AppCompatActivity {

    LocationRequest locationRequest;
    FusedLocationProviderClient fusedLocationClient;
    LocationCallback locationCallback;

    private double latitude;
    public double longitude;
    public String address;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_location_services);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        requestPermissions();
        createLocationRequestLocationCallback();
        createLocationServicesClient();
    }

    public boolean requestPermissions() {

        int REQUEST_PERMISSION = 3000;

        String permissions[] = {
                android.Manifest.permission.ACCESS_FINE_LOCATION,
                android.Manifest.permission.ACCESS_COARSE_LOCATION
        };

        boolean grantFinePermission =
                ContextCompat.checkSelfPermission(this, permissions[0])
                        == PackageManager.PERMISSION_GRANTED;

        boolean grantCoarsePermission =
                ContextCompat.checkSelfPermission(this, permissions[1])
                        == PackageManager.PERMISSION_GRANTED;

        if (!grantFinePermission && !grantCoarsePermission) {
            ActivityCompat.requestPermissions(this, permissions, REQUEST_PERMISSION);

        } else if (!grantFinePermission) {
            ActivityCompat.requestPermissions(this,
                    new String[]{permissions[0]}, REQUEST_PERMISSION);

        } else if (!grantCoarsePermission) {
            ActivityCompat.requestPermissions(this,
                    new String[]{permissions[1]}, REQUEST_PERMISSION);
        }

        return grantFinePermission && grantCoarsePermission;
    }

    public void createLocationServicesClient() {

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        if (ActivityCompat.checkSelfPermission(this,
                android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this,
                        android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        startLocationUpdates();
    }

    public void createLocationRequestLocationCallback() {

        locationRequest = new LocationRequest.Builder(
                Priority.PRIORITY_HIGH_ACCURACY, 2000).build();

        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {

                Location location = locationResult.getLastLocation();

                if (location != null) {

                    latitude = location.getLatitude();
                    longitude = location.getLongitude();

                    showLocationAddress();
                }
            }
        };
    }

    public void showLocationAddress() {

        TextView tvlat = findViewById(R.id.textViewLatitude);
        TextView tvlng = findViewById(R.id.textViewLongitude);
        TextView tvaddr = findViewById(R.id.textViewAddress);

        tvlat.setText("Latitude: " + latitude);
        tvlng.setText("Longitude: " + longitude);

        try {

            Geocoder geocoder = new Geocoder(this, Locale.getDefault());

            List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);

            if (addresses != null && !addresses.isEmpty()) {

                Address addr = addresses.get(0);

                address = "Address: " + addr.getAddressLine(0);

            } else {
                address = "Address: Unknown";
            }

        } catch (Exception e) {

            address = "Address: Service unavailable";
            e.printStackTrace();
        }

        tvaddr.setText(address);
    }

    public void startLocationUpdates() {

        if (ActivityCompat.checkSelfPermission(this,
                android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this,
                        android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        fusedLocationClient.requestLocationUpdates(
                locationRequest,
                locationCallback,
                Looper.getMainLooper());
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 3000) {

            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                createLocationRequestLocationCallback();
                createLocationServicesClient();
            }
        }
    }
}